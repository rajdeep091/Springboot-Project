package net.javaguides.employeeservice.mapper;

import net.javaguides.employeeservice.dto.AddressDto;
import net.javaguides.employeeservice.dto.EmployeeDto;
import net.javaguides.employeeservice.entity.Address;
import net.javaguides.employeeservice.entity.Employee;
import net.javaguides.employeeservice.repository.AddressRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class EmployeeMapper {

    @Autowired
    private AddressRepository addressRepository;

    public static EmployeeDto mapToEmployeeDto(Employee employee) {
        EmployeeDto employeeDto = new EmployeeDto();
        if (Objects.nonNull(employee)) {
            employeeDto.setEmail(employee.getEmail());
            employeeDto.setDepartmentCode(employee.getDepartmentCode());
            employeeDto.setFirstName(employee.getFirstName());
            employeeDto.setLastName(employee.getLastName());
            employeeDto.setId(employee.getId());
            employeeDto.setOrganizationCode(employee.getOrganizationCode());
            if (!CollectionUtils.isEmpty(employee.getAddress())) {
                List<AddressDto> addressList = new ArrayList<>();
                employee.getAddress().forEach(address -> {
                    AddressDto address1 = new AddressDto();
                    address1.setAddressId(address.getAddressId());
                    address1.setCity(address.getCity());
                    address1.setAddressType(address.getAddressType());
//                    address1.setEmployee(employeeDto);
                    addressList.add(address1);
                });
                employeeDto.setAddress(addressList);
            }
        }
        return employeeDto;
    }


    public static Employee mapToEmployee(EmployeeDto employeeDto){
        Employee employee = new Employee();
        BeanUtils.copyProperties(employeeDto, employee);
        List<Address> addressList = new ArrayList<>();
        employeeDto.getAddress().forEach(address -> {
            Address address1 = new Address();
            BeanUtils.copyProperties(address, address1);
            addressList.add(address1);
        });
        employee.setAddress(addressList);
        return employee;
    }

    public static Employee updateEmployeeMapper(EmployeeDto employeeDto, Employee employee1) {
        employee1.setEmail(employeeDto.getEmail());
        employee1.setFirstName(employeeDto.getFirstName());
        employee1.setLastName(employeeDto.getLastName());
        employee1.setDepartmentCode(employeeDto.getDepartmentCode());
        employee1.setOrganizationCode(employeeDto.getOrganizationCode());
        List<Address> addressList = new ArrayList<>();
        employeeDto.getAddress().forEach(address -> {
            Address address1 = new Address();
            address1.setEmployee(employee1);
            BeanUtils.copyProperties(address, address1);
            addressList.add(address1);
        });
        employee1.setAddress(addressList);
        return employee1;
    }
}
