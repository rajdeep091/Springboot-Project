package net.javaguides.employeeservice.aspect;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    @Before("execution(* net.javaguides.employeeservice.service.EmployeeService.*(..))")
    public void logBeforeAllMethods(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeAllMethods() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.employeeservice.service.EmployeeService.getEmployeeById(..))")
    public void logBeforeGetEmployeeById(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeGetEmployeeById() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.employeeservice.service.EmployeeService.saveEmployee(..))")
    public void logBeforeSaveEmployee(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeSaveEmployee() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.employeeservice.service.EmployeeService.updateEmployee(..))")
    public void logBeforeUpdateEmployee(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeUpdateEmployee() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.employeeservice.service.EmployeeService.deleteEmployee(..))")
    public void logBeforeDeleteEmployee(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeDeleteEmployee() : " + joinPoint.getSignature().getName());
    }
    @After("execution(* net.javaguides.employeeservice.service.EmployeeService.*(..))")
    public void logAfterAllMethods(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterAllMethods() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.employeeservice.service.EmployeeService.getEmployeeById(..))")
    public void logAfterGetEmployeeById(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterGetEmployeeById() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.employeeservice.service.EmployeeService.saveEmployee(..))")
    public void logAfterSaveEmployee(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterSaveEmployee() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.employeeservice.service.EmployeeService.updateEmployee(..))")
    public void logAfterUpdateEmployee(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterUpdateEmployee() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.employeeservice.service.EmployeeService.deleteEmployee(..))")
    public void logAfterDeleteEmployee(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterDeleteEmployee() : " + joinPoint.getSignature().getName());
    }

}
