package net.javaguides.employeeservice.entity;

import lombok.*;

import jakarta.persistence.*;
import net.javaguides.employeeservice.dto.AddressDto;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String firstName;
    private String lastName;
    @Column(nullable = false, unique = true)
    private String email;
    private String departmentCode;
    private String organizationCode;
    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL)
    private List<Address> address;

}
