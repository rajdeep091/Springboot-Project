package net.javaguides.employeeservice.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource(value= {"classpath:application-local.properties"})
@Data
public class EmployeeConfig {

    @Value("${department.url}")
    private String departmentUrl;

    @Value("${organization.url}")
    private String organizationUrl;


}
