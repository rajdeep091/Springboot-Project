package net.javaguides.employeeservice.service.impl;

import lombok.AllArgsConstructor;
import net.javaguides.employeeservice.config.EmployeeConfig;
import net.javaguides.employeeservice.dto.*;
import net.javaguides.employeeservice.entity.Address;
import net.javaguides.employeeservice.entity.Employee;
import net.javaguides.employeeservice.exception.ResourceNotFoundException;
import net.javaguides.employeeservice.mapper.EmployeeMapper;
import net.javaguides.employeeservice.repository.AddressRepository;
import net.javaguides.employeeservice.repository.EmployeeRepository;
import net.javaguides.employeeservice.service.EmployeeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeConfig employeeConfig;

    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeServiceImpl.class);

    private EmployeeRepository employeeRepository;

    private AddressRepository addressRepository;

    private RestTemplate restTemplate;

    @Override
    public APIResponseDto saveEmployee(EmployeeDto employeeDto) throws Exception {

        ResponseEntity<DepartmentDto> responseEntity = restTemplate.getForEntity( employeeConfig.getDepartmentUrl()+ employeeDto.getDepartmentCode(),
                DepartmentDto.class);
        DepartmentDto departmentDto = responseEntity.getBody();
        if(Objects.isNull(responseEntity.getBody())){
            throw new ResourceNotFoundException("404", "Department does not exist");
        }

        ResponseEntity<OrganizationDto> responseEntity2 = restTemplate.getForEntity(employeeConfig.getOrganizationUrl() + employeeDto.getOrganizationCode(),
                OrganizationDto.class);
        OrganizationDto organizationDto = responseEntity2.getBody();
        if(Objects.isNull(responseEntity2.getBody())){
            throw new ResourceNotFoundException("404", "Organization does not exist");
        }

        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);

        Employee savedEmployee = employeeRepository.save(employee);
        employee.getAddress().forEach(address -> {
            address.setEmployee(employee);
            addressRepository.save(address);
        });

        EmployeeDto savedEmployeeDto = EmployeeMapper.mapToEmployeeDto(savedEmployee);

        APIResponseDto apiResponseDto = new APIResponseDto();
        apiResponseDto.setEmployee(savedEmployeeDto);
        apiResponseDto.setDepartment(departmentDto);
        apiResponseDto.setOrganization(organizationDto);
        return apiResponseDto;

    }

    @Override
    public APIResponseDto getEmployeeById(Long employeeId) {

        LOGGER.info("inside getEmployeeById() method");
        Employee employee = employeeRepository.findById(employeeId).get();

        ResponseEntity<DepartmentDto> responseEntity = restTemplate.getForEntity(employeeConfig.getDepartmentUrl() + employee.getDepartmentCode(),
                DepartmentDto.class);

        DepartmentDto departmentDto = responseEntity.getBody();

        ResponseEntity<OrganizationDto> responseEntity1 = restTemplate.getForEntity(employeeConfig.getOrganizationUrl() + employee.getOrganizationCode(),
                OrganizationDto.class);

       OrganizationDto organizationDto = responseEntity1.getBody();

        EmployeeDto employeeDto = EmployeeMapper.mapToEmployeeDto(employee);

        APIResponseDto apiResponseDto = new APIResponseDto();
        apiResponseDto.setEmployee(employeeDto);
        apiResponseDto.setDepartment(departmentDto);
        apiResponseDto.setOrganization(organizationDto);
        return apiResponseDto;
    }

    @Override
    public String updateEmployee(EmployeeDto employeeDto) {
        Employee employee1 = employeeRepository.findById(employeeDto.getId()).orElseThrow(() -> new ResourceNotFoundException("404", "Id not found"));
        var emp = EmployeeMapper.updateEmployeeMapper(employeeDto, employee1);
        employeeRepository.save(emp);
        return "Updated Successfully";
    }

    @Override
    public void deleteEmployee(EmployeeDto employeeDto) {
        Employee employee1 = employeeRepository.findById(employeeDto.getId()).orElseThrow(() -> new ResourceNotFoundException("404", "Id not found"));
        employeeRepository.delete(employee1);
//        List<AddressDto> addressList = employeeDto.getAddress();
//        addressList.forEach(addressDto -> {
//            Address address = addressRepository.findById(employeeDto.getId()).orElseThrow(() -> new ResourceNotFoundException("404", "Address not found"));
//            addressRepository.delete(address);
//        });


    }

}
