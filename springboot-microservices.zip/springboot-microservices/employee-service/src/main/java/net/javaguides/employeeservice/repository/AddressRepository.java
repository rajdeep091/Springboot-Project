package net.javaguides.employeeservice.repository;

import net.javaguides.employeeservice.entity.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {
}
