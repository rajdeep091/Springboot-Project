package net.javaguides.employeeservice.service;

import net.javaguides.employeeservice.dto.APIResponseDto;
import net.javaguides.employeeservice.dto.EmployeeDto;
import net.javaguides.employeeservice.entity.Employee;

public interface EmployeeService {
    APIResponseDto saveEmployee (EmployeeDto employeeDto)throws Exception;

    APIResponseDto getEmployeeById(Long employeeId);

    String updateEmployee(EmployeeDto employeedDto);

    void deleteEmployee(EmployeeDto employeedDto);
}
