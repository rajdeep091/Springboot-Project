package net.javaguides.organizationservice.aspect;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    @Before("execution(* net.javaguides.organizationservice.service.OrganizationService.*(..))")
    public void logBeforeAllMethods(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeAllMethods() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.organizationservice.service.getOrganizationByCode(..))")
    public void logBeforeGetOrganizationByCode(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeGetOrganizationByCode() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.organizationservice.service.saveOrganization(..))")
    public void logBeforeSaveOrganization(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeSaveOrganization() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.organizationservice.service.updateOrganization(..))")
    public void logBeforeUpdateOrganization(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeUpdateOrganization() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.organizationservice.service.deleteOrganization(..))")
    public void logBeforeDeleteOrganization(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeDeleteOrganization() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.organizationservice.service.OrganizationService*(..))")
    public void logAfterAllMethods(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeAllMethods() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.organizationservice.service.getOrganizationByCode(..))")
    public void logAfterGetOrganizationByCode(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterGetOrganizationByCode() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.organizationservice.service.saveOrganization(..))")
    public void logAfterSaveOrganization(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterSaveOrganization() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.organizationservice.service.updateOrganization(..))")
    public void logAfterUpdateOrganization(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterUpdateOrganization() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.organizationservice.service.deleteOrganization(..))")
    public void logAfterDeleteOrganization(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterDeleteOrganization() : " + joinPoint.getSignature().getName());
    }

    @AfterThrowing(pointcut = "execution(* net.javaguides.organizationservice.service.OrganizationService.*(..))", throwing = "ex")
    public void logAfterThrowingAllMethods(Exception ex) throws Throwable {
        log.debug("****LoggingAspect.logAfterThrowingAllMethods() " + ex);;
    }

}
