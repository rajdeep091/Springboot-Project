package net.javaguides.organizationservice.service.impl;

import lombok.AllArgsConstructor;
import net.javaguides.organizationservice.dto.OrganizationDto;
import net.javaguides.organizationservice.entity.Organization;
import net.javaguides.organizationservice.exception.ResourceNotFoundException;
import net.javaguides.organizationservice.mapper.OrganizationMapper;
import net.javaguides.organizationservice.repository.OrganizationRepository;
import net.javaguides.organizationservice.service.OrganizationService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@AllArgsConstructor
public class OrganizationServiceImpl implements OrganizationService {

    private OrganizationRepository organizationRepository;

    @Override
    public OrganizationDto saveOrganization(OrganizationDto organizationDto) {

        Organization organization = OrganizationMapper.mapToOrganization(organizationDto);

        Organization savedOrganization = organizationRepository.save(organization);

        return OrganizationMapper.mapToOrganizationDto(savedOrganization);
    }

    @Override
    public OrganizationDto getOrganizationByCode(String organizationCode) {
        OrganizationDto organizationDto = null;
        try{
            Organization organization = organizationRepository.findByOrganizationCode(organizationCode);
            organizationDto = OrganizationMapper.mapToOrganizationDto(organization);
        } catch(Exception e) {
            System.out.println(e.getLocalizedMessage());
        }
        return organizationDto;
    }

    @Override
    public String updateOrganization(OrganizationDto organizationDto) {
        Organization organization1 = organizationRepository.findById(organizationDto.getId()).orElseThrow(() -> new ResourceNotFoundException("404", "Id not found"));
        organization1.setOrganizationName(organizationDto.getOrganizationName());
        organization1.setOrganizationCode(organizationDto.getOrganizationCode());
        organization1.setOrganizationDescription(organizationDto.getOrganizationDescription());
        organization1.setCreatedDate(LocalDateTime.now());
        Organization organization2 = organizationRepository.save(organization1);
        return "Organization details updated successfully";
    }

    @Override
    public void deleteOrganization(OrganizationDto organizationDto) {
        Organization organization1 = organizationRepository.findById(organizationDto.getId()).orElseThrow(() -> new ResourceNotFoundException("404", "Id not found"));
        organizationRepository.delete(organization1);
    }
}
