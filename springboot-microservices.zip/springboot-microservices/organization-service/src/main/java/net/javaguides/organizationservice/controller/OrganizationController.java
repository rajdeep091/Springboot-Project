package net.javaguides.organizationservice.controller;

import lombok.AllArgsConstructor;
import net.javaguides.organizationservice.dto.OrganizationDto;
import net.javaguides.organizationservice.entity.Organization;
import net.javaguides.organizationservice.exception.ResourceNotFoundException;
import net.javaguides.organizationservice.service.OrganizationService;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

@RestController
@RequestMapping("api/organizations")
@AllArgsConstructor
public class OrganizationController {

    private OrganizationService organizationService;

    // Build Save Organization REST API
    @PostMapping
    public ResponseEntity<OrganizationDto> saveOrganization(@RequestBody OrganizationDto organizationDto){
        OrganizationDto savedOrganization = organizationService.saveOrganization(organizationDto);
        return new ResponseEntity<>(savedOrganization, HttpStatus.CREATED);
    }

    // Build Get Organization by Code REST API
    @GetMapping("{code}")
    @Cacheable(value = "organizationInfo")
    public ResponseEntity<OrganizationDto> getOrganization(@PathVariable("code") String organizationCode){
        OrganizationDto organizationDto = organizationService.getOrganizationByCode(organizationCode);
        if(Objects.isNull(organizationDto)) {
            throw  new ResourceNotFoundException("404", "Organization not found");
        } else{
            return ResponseEntity.ok(organizationDto);

        }
    }

    @PutMapping("/update-organization")
    public ResponseEntity<String> updateEmployee(@RequestBody OrganizationDto organizationDto){
        var organization1 = organizationService.updateOrganization(organizationDto);
        return new ResponseEntity<>(organization1, HttpStatus.OK);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteOrganization(@RequestBody OrganizationDto organizationDto){
        organizationService.deleteOrganization(organizationDto);
        return  new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
    }

}
