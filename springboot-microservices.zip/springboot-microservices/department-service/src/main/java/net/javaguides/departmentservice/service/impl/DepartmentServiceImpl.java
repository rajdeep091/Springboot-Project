package net.javaguides.departmentservice.service.impl;

import lombok.AllArgsConstructor;
import net.javaguides.departmentservice.dto.DepartmentDto;
import net.javaguides.departmentservice.entity.Department;
import net.javaguides.departmentservice.exception.ResourceNotFoundException;
import net.javaguides.departmentservice.mapper.DepartmentMapper;
import net.javaguides.departmentservice.repository.DepartmentRepository;
import net.javaguides.departmentservice.service.DepartmentService;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {

    private DepartmentRepository departmentRepository;

    @Override
    public DepartmentDto saveDepartment(DepartmentDto departmentDto) {


        Department department = DepartmentMapper.mapToDepartment(departmentDto);

        Department savedDepartment = departmentRepository.save(department);

        DepartmentDto savedDepartmentDto = DepartmentMapper.mapToDepartmentDto(savedDepartment);

        return savedDepartmentDto;
    }

    @Override
    public DepartmentDto getDepartmentByCode(String departmentCode) {
        DepartmentDto departmentDto = null;
        try {
            Department department = departmentRepository.findByDepartmentCode(departmentCode);

            departmentDto = DepartmentMapper.mapToDepartmentDto(department);

        } catch (Exception e){
            System.out.println(e.getLocalizedMessage());
        }
        return departmentDto;

    }

    @Override
    public String updateDepartment(DepartmentDto departmentDto) {
        Department department1 = departmentRepository.findById(departmentDto.getId()).orElseThrow(() -> new ResourceNotFoundException("404", "Id not found"));
        department1.setDepartmentName(departmentDto.getDepartmentName());
        department1.setDepartmentDescription(departmentDto.getDepartmentDescription());
        department1.setDepartmentCode(departmentDto.getDepartmentCode());
        Department department2 = departmentRepository.save(department1);
        return "Department details updated successfully";
    }

    @Override
    public void deleteDepartment(DepartmentDto departmentDto) {
        Department department = departmentRepository.findById(departmentDto.getId()).orElseThrow(() -> new ResourceNotFoundException("404", "Id not found"));
        departmentRepository.delete(department);

    }

}
