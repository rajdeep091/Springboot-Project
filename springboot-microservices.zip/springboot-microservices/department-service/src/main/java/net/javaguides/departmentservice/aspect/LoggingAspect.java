package net.javaguides.departmentservice.aspect;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Aspect
@Component
public class LoggingAspect {

    private final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    @Before("execution(* net.javaguides.departmentservice.service.DepartmentService.*(..))")
    public void logBeforeAllMethods(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeAllMethods() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.departmentservice.service.DepartmentService.getDepartmentByCode(..))")
    public void logBeforeGetDepartmentByCode(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeGetDepartmentByCode() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.departmentservice.service.DepartmentService.saveDepartment(..))")
    public void logBeforeSaveDepartment(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeSaveDepartment() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.departmentservice.service.DepartmentService.updateDepartment(..))")
    public void logBeforeUpdateDepartment(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeUpdateDepartment() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* net.javaguides.departmentservice.service.DepartmentService.deleteDepartment(..))")
    public void logBeforeDeleteDepartment(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeDeleteDepartment() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.departmentservice.service.DepartmentService.*(..))")
    public void logAfterAllMethods(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logBeforeAllMethods() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.departmentservice.service.DepartmentService.getDepartmentByCode(..))")
    public void logAfterGetDepartmentByCode(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterGetDepartmentByCode() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.departmentservice.service.DepartmentService.saveDepartment(..))")
    public void logAfterSaveDepartment(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterSaveDepartment() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.departmentservice.service.DepartmentService.updateDepartment(..))")
    public void logAfterUpdateDepartment(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterUpdateDepartment() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* net.javaguides.departmentservice.service.DepartmentService.deleteDepartment(..))")
    public void logAfterDeleteDepartment(JoinPoint joinPoint) {
        log.debug("****LoggingAspect.logAfterDeleteDepartment() : " + joinPoint.getSignature().getName());
    }

    @AfterThrowing(pointcut = "execution(* net.javaguides.departmentservice.service.DepartmentService.*(..))", throwing = "ex")
    public void logAfterThrowingAllMethods(Exception ex) throws Throwable {
        log.debug("****LoggingAspect.logAfterThrowingAllMethods() " + ex);;
    }

}
