package net.javaguides.departmentservice.controller;

import lombok.AllArgsConstructor;
import net.javaguides.departmentservice.dto.DepartmentDto;
import net.javaguides.departmentservice.entity.Department;
import net.javaguides.departmentservice.exception.ResourceNotFoundException;
import net.javaguides.departmentservice.service.DepartmentService;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

@RestController
@RequestMapping("api/departments")
@AllArgsConstructor
public class DepartmentController {

    private DepartmentService departmentService;

    // Build save department REST API
    @PostMapping
    public ResponseEntity<DepartmentDto> saveDepartment(@RequestBody DepartmentDto departmentDto){
        DepartmentDto savedDepartment = departmentService.saveDepartment(departmentDto);
        return new ResponseEntity<>(savedDepartment, HttpStatus.CREATED);
    }

    // Build get department rest api
    @GetMapping("{department-code}")
    @Cacheable(value = "departmentInfo")
    public ResponseEntity<DepartmentDto> getDepartment(@PathVariable("department-code") String departmentCode){
        DepartmentDto departmentDto = departmentService.getDepartmentByCode(departmentCode);
        if(Objects.isNull(departmentDto)) {
            throw  new ResourceNotFoundException("404", "Dpartment not found");
        } else{
            return new ResponseEntity<>(departmentDto, HttpStatus.OK);
        }
    }

    @PutMapping("/update-department")
    public ResponseEntity<String> updateDepartment(@RequestBody DepartmentDto departmentDto){
        var department1 = departmentService.updateDepartment(departmentDto);
        return new ResponseEntity<>(department1, HttpStatus.OK);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteEmployee(@RequestBody DepartmentDto departmentDto){
        departmentService.deleteDepartment(departmentDto);
        return  new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
    }
}
